#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mat2qimage.h"

#include<opencv2/core/core.hpp>
#include<opencv2/ml/ml.hpp>
#include<opencv/cv.h>
#include<opencv2/imgproc/imgproc.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/video/background_segm.hpp>
#include<opencv2/videoio.hpp>
#include<opencv2/imgcodecs.hpp>
#include<qdebug.h>
#include<QTimer>

#include<opencv2/objdetect.hpp>


//cv::VideoCapture camara(1);

using namespace cv;
QString IPcam = "http://192.168.43.1:8080/video";

//cv::VideoCapture camara("http://192.168.43.243:8080/video");
cv::VideoCapture camara(IPcam.toUtf8().constData());

CascadeClassifier face_cascade;
CascadeClassifier eyes_cascade;
QString face_cascade_name = "../haarcascade_frontalface_alt_tree.xml";
//QString face_cascade_name = "../haarcascade_frontalface_alt2.xml";
//
//QString face_cascade_name = "../haarcascade_licence_plate_rus_16stages.xml";
QString eyes_cascade_name = "../haarcascade_eye_tree_eyeglasses.xml";

void MainWindow::fTimer(){

    //Mat IMAGEN(300,400,CV_8UC3,Scalar(150,255,25));
    Mat IMAGEN;
    Mat IMAGEN2;
   // if(camara.isOpened()){
    //camara >> IMAGEN;
    camara.read(IMAGEN);
   //IMAGEN.copyTo(IMAGEN2);
    cv::resize(IMAGEN,IMAGEN2,Size(256,144),0,0,0);

    // detectAndDisplay( IMAGEN2 );
    std::vector<Rect> faces;
    Mat frame_gray;
    cv::cvtColor( IMAGEN2, frame_gray, COLOR_BGR2GRAY );
    cv::equalizeHist( frame_gray, frame_gray );
    face_cascade.detectMultiScale( frame_gray, faces, 1.1, 2, 0|CASCADE_SCALE_IMAGE, Size(30, 30) );

    for ( size_t i = 0; i < faces.size(); i++ )
        {
            Point center( faces[i].x + faces[i].width/2, faces[i].y + faces[i].height/2 );
            ellipse( IMAGEN2, center, Size( faces[i].width/2, faces[i].height/2 ), 0, 0, 360, Scalar( 255, 255, 255 ), 4, 8, 0 );

            Mat faceROI = frame_gray( faces[i] );
            QString nombreImagen = "img" + QString::number(i)+".jpg";
            cv::imwrite(nombreImagen.toUtf8().constData(),faceROI);
            /*
            std::vector<Rect> eyes;
            //-- In each face, detect eyes

            eyes_cascade.detectMultiScale( faceROI, eyes, 1.1, 2, 0 |CASCADE_SCALE_IMAGE, Size(30, 30) );
            for ( size_t j = 0; j < eyes.size(); j++ ){
                Point eye_center( faces[i].x + eyes[j].x + eyes[j].width/2, faces[i].y + eyes[j].y + eyes[j].height/2 );
                int radius = cvRound( (eyes[j].width + eyes[j].height)*0.25 );
                circle( IMAGEN2, eye_center, radius, Scalar( 255, 0, 0 ), 4, 8, 0 );
            }
            */

        }


    QImage qImage = Mat2QImage(IMAGEN2);
    QPixmap pixmap = QPixmap::fromImage(qImage);
    ui->label->clear();
    ui->label->setPixmap(pixmap);
   //d }
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{


    ui->setupUi(this);

    QTimer *cronometro=new QTimer(this);
    connect(cronometro, SIGNAL(timeout()), this, SLOT(fTimer()));
    cronometro->start(100);


    //if(!camara.isOpened()) camara("http://192.168.43.243:8080/video");
      if(!camara.isOpened()) camara.open(IPcam.toUtf8().constData());


    else         qDebug() << "No se abre la camara 22";


      if( !face_cascade.load( face_cascade_name.toUtf8().constData() ) ){ qDebug() << "Error al cargar el detector de rostros"; }
      if( !eyes_cascade.load( eyes_cascade_name.toUtf8().constData() ) ){ qDebug() << "Error al cargar el detector de ojos"; }


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
     //system("ssmtp ruben.estrada@hetpro.com.mx < correo.txt");
    //mpack -s subject picture.png mail.address@example.com
    Mat IMAGEN;
    camara >> IMAGEN;
    cv::imwrite("picture.png",IMAGEN);
    system("mpack -s subject picture.png ruben.estrada@hetpro.com.mx");
}
